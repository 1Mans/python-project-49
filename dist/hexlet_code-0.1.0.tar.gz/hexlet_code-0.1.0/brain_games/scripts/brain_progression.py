from brain_games.games import progression
from brain_games.logic import go

def main():
    go(progression)


if __name__ == '__main__':
    main()
